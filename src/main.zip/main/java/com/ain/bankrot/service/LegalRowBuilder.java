package com.ain.bankrot.service;

import com.ain.bankrot.api.ApiClient;
import com.ain.bankrot.api.FedresursEndpoints;
import com.ain.bankrot.model.legal.LegalEntityRow;
import com.ain.bankrot.util.Dates;
import com.ain.bankrot.util.RegionExtractor;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ain.bankrot.util.TradesHtmlParser;

import java.util.Map;

public class LegalRowBuilder {

    private final ApiClient fed;
    private final ApiClient bankrot;

    private final ObjectMapper om = new ObjectMapper();
    private final CompanyMapper companyMapper = new CompanyMapper();

    private static final boolean DEBUG_TRADES = true;

    public LegalRowBuilder(ApiClient fed, ApiClient bankrot) {
        this.fed = fed;
        this.bankrot = bankrot;
    }

    public LegalEntityRow buildFromListItem(JsonNode itemFromBankrotList) throws Exception {
        String guid = itemFromBankrotList.path("guid").asText("");
        LegalEntityRow row = new LegalEntityRow();
        if (guid.isBlank()) return row;

        // 1) ДАННЫЕ ИЗ СПИСКА (bankrot.*) — lastLegalCase
        JsonNode last = itemFromBankrotList.path("lastLegalCase");

        row.caseNumber = firstNonBlank(
                last.path("number").asText(""),
                last.path("caseNumber").asText(""),
                last.path("case").path("number").asText("")
        );

        row.caseStatus = firstNonBlank(
                last.path("status").path("description").asText(""),
                last.path("status").path("name").asText(""),
                last.path("statusName").asText(""),
                last.path("caseStatus").asText(""),
                last.path("status").asText("")
        );
// TradesCount: берём из HTML карточки компании
        // 1) пробуем получить из HTML
        String trades = TradesHtmlParser.fetchTradesCount(guid);

// 2) fallback если null/пусто
        if (trades == null || trades.isBlank()) {
            trades = "0";
        }

// 3) присваиваем
        row.tradesCount = trades;

// 4) лог уже финального значения
        System.out.println("DEBUG TradesCount guid=" + guid + " -> " + row.tradesCount);
        row.procedureType = extractProcedureTypeFromLastLegalCase(last);

        row.arbitrationManagerName = firstNonBlank(
                last.path("arbitrManagerFio").asText(""),
                last.path("arbitrationManager").path("name").asText(""),
                last.path("arbitrManager").path("name").asText(""),
                last.path("manager").path("name").asText("")
        );

        row.arbitrationManagerInn = firstNonBlank(
                last.path("arbitrManagerInn").asText(""),
                last.path("arbitrManagerINN").asText(""),
                last.path("arbitrationManager").path("inn").asText(""),
                last.path("manager").path("inn").asText("")
        );

        row.managerAppointmentDate = Dates.toDdMmYyyyFromIsoDateTime(firstNonBlank(
                last.path("managerAppointmentDate").asText(""),
                last.path("appointmentDate").asText(""),
                last.path("arbitrManagerDate").asText(""),
                last.path("arbitrManagerSince").asText("")
        ));

        row.region = firstNonBlank(
                itemFromBankrotList.path("region").path("name").asText(""),
                itemFromBankrotList.path("region").asText("")
        );

        // 2) КАРТОЧКА КОМПАНИИ (fedresurs.ru)
        String companyPath = FedresursEndpoints.company(guid);
        String companyJson = fed.get(companyPath, refererFed());
        LegalEntityRow base = companyMapper.fromCompanyJson(companyJson, "https://fedresurs.ru" + companyPath);
        mergeLegal(row, base);

        if (row.region.isBlank()) row.region = RegionExtractor.extract(row.address);

        // 3) publicationsCount (обычно fedresurs)
        row.publicationsCount = readCountSafe(
                fed, "https://fedresurs.ru",
                FedresursEndpoints.companyPublications(guid, 1, 0),
                false
        );

        // 4) tradesCount (ВАЖНО: bankrot.fedresurs.ru)
        row.tradesCount = readCountSafe(
                fed, "https://fedresurs.ru",
                FedresursEndpoints.companyTradesFed(guid, 1, 0),
                true
        );
        // 5) BANKRUPTCY DETAILS → CaseEndDate + добивки
        fillFromBankruptcy(row, guid);

        // 6) IEB → INN управляющего + дата назначения
        fillFromIeb(row, guid);

        return row;
    }

    // =========================================================
    // Bankruptcy block
    // =========================================================
    private void fillFromBankruptcy(LegalEntityRow row, String guid) {
        try {
            String bjson = fed.get(FedresursEndpoints.companyBankruptcy(guid), refererFed());
            JsonNode broot = om.readTree(bjson);

            String endIso = firstNonBlank(
                    findDeep(broot, "caseEndDate", "endDate", "dateEnd", "finishDate", "completionDate")
            );
            if (!endIso.isBlank()) {
                row.caseEndDate = Dates.toDdMmYyyyFromIsoDateTime(endIso);
            }

            JsonNode firstCase = firstLegalCase(broot);

            if (row.caseNumber.isBlank()) {
                row.caseNumber = firstNonBlank(
                        findDeep(broot, "caseNumber"),
                        firstCase != null ? firstCase.path("number").asText("") : ""
                );
            }

            if (row.caseStatus.isBlank()) {
                row.caseStatus = firstNonBlank(
                        findDeep(broot, "caseStatus", "statusName"),
                        firstCase != null ? firstCase.path("status").path("name").asText("") : "",
                        firstCase != null ? firstCase.path("status").path("description").asText("") : ""
                );
            }

            if (row.procedureType.isBlank()) {
                row.procedureType = firstNonBlank(
                        broot.path("procedure").path("name").asText(""),
                        broot.path("procedure").path("description").asText(""),
                        broot.path("procedure").path("type").asText(""),
                        broot.path("procedureType").asText(""),
                        firstCase != null ? firstCase.path("procedure").path("name").asText("") : "",
                        firstCase != null ? firstCase.path("procedure").path("description").asText("") : "",
                        findDeep(broot, "procedureType", "procedureName")
                );

                if (row.procedureType.isBlank()) {
                    String maybe = broot.path("procedure").asText("");
                    if (!maybe.isBlank()) row.procedureType = maybe;
                }
            }

        } catch (Exception ignore) {}
    }

    private static JsonNode firstLegalCase(JsonNode broot) {
        JsonNode arr = broot.path("legalCases");
        if (arr.isArray() && arr.size() > 0) return arr.get(0);
        return null;
    }

    // =========================================================
    // IEB block
    // =========================================================
    private void fillFromIeb(LegalEntityRow row, String guid) {
        try {
            String ij = fed.get(FedresursEndpoints.companyIeb(guid), refererFed());
            JsonNode ir = om.readTree(ij);

            String inn = firstNonBlank(
                    findDeep(ir, "arbitrationManagerInn", "arbitrationManagerINN"),
                    ir.path("arbitrationManager").path("inn").asText(""),
                    ir.path("manager").path("inn").asText(""),
                    ir.path("inn").asText("")
            );
            if (!inn.isBlank() && row.arbitrationManagerInn.isBlank()) {
                row.arbitrationManagerInn = inn;
            }

            String appIso = firstNonBlank(
                    findDeep(ir, "managerAppointmentDate", "appointmentDate"),
                    findDeep(ir, "egrulDateCreate"),
                    ir.path("date").asText("")
            );
            String app = Dates.toDdMmYyyyFromIsoDateTime(appIso);
            if (!app.isBlank() && row.managerAppointmentDate.isBlank()) {
                row.managerAppointmentDate = app;
            }

        } catch (Exception ignore) {}
    }

    // =========================================================
    // Helpers
    // =========================================================

    private String readCountSafe(ApiClient client, String baseUrl, String path, boolean isTrades) {
        try {
            String j = client.get(path, refererForBase(baseUrl));

            if (isTrades && DEBUG_TRADES) {
                System.out.println("TRADES URL = " + baseUrl + path);
                System.out.println("TRADES RESP head = " + j.substring(0, Math.min(160, j.length())));
            }

            JsonNode root = om.readTree(j);

            int found = root.path("found").asInt(-1);
            if (found >= 0) return String.valueOf(found);

            int total = root.path("total").asInt(-1);
            if (total >= 0) return String.valueOf(total);

            int count = root.path("count").asInt(-1);
            if (count >= 0) return String.valueOf(count);

            JsonNode pd = root.path("pageData");
            if (pd.isArray()) return String.valueOf(pd.size());

            return "";
        } catch (Exception e) {
            return "";
        }
    }

    private static Map<String, String> refererForBase(String baseUrl) {
        return Map.of("Referer", baseUrl.endsWith("/") ? baseUrl : (baseUrl + "/"));
    }

    private static Map<String, String> refererFed() {
        return Map.of("Referer", "https://fedresurs.ru/");
    }

    private static String extractProcedureTypeFromLastLegalCase(JsonNode last) {
        if (last == null || last.isMissingNode() || last.isNull()) return "";

        String p1 = last.path("procedure").path("name").asText("");
        if (!p1.isBlank()) return p1;

        String p1b = last.path("procedure").path("description").asText("");
        if (!p1b.isBlank()) return p1b;

        String p1c = last.path("procedure").path("type").asText("");
        if (!p1c.isBlank()) return p1c;

        String p2 = last.path("procedure").asText("");
        if (!p2.isBlank()) return p2;

        String p3 = last.path("procedureType").asText("");
        if (!p3.isBlank()) return p3;

        String p4 = last.path("procedureName").asText("");
        if (!p4.isBlank()) return p4;

        String p5 = last.path("type").asText("");
        if (!p5.isBlank()) return p5;

        return "";
    }

    private static void mergeLegal(LegalEntityRow target, LegalEntityRow base) {
        target.fullName = base.fullName;
        target.inn = base.inn;
        target.ogrn = base.ogrn;
        target.kpp = base.kpp;
        target.authorizedCapital = base.authorizedCapital;
        target.registrationDate = base.registrationDate;
        target.address = base.address;
        if (target.region.isBlank()) target.region = base.region;
        target.legalForm = base.legalForm;
        target.okved = base.okved;
        target.status = base.status;
        target.sourceUrl = base.sourceUrl;
    }

    private static String firstNonBlank(String... xs) {
        for (String x : xs) if (x != null && !x.isBlank()) return x.trim();
        return "";
    }

    private static String findDeep(JsonNode root, String... keys) {
        if (root == null || root.isNull() || root.isMissingNode()) return "";
        for (String k : keys) {
            String v = findByKey(root, k);
            if (v != null && !v.isBlank()) return v.trim();
        }
        return "";
    }

    private static String findByKey(JsonNode node, String key) {
        if (node == null || node.isNull() || node.isMissingNode()) return null;

        if (node.isObject()) {
            JsonNode direct = node.get(key);
            if (direct != null && !direct.isNull()) {

                String s = direct.asText("");
                if (s != null && !s.isBlank()) return s;

                String name = direct.path("name").asText("");
                if (!name.isBlank()) return name;

                String desc = direct.path("description").asText("");
                if (!desc.isBlank()) return desc;
            }

            var it = node.fields();
            while (it.hasNext()) {
                var e = it.next();
                String got = findByKey(e.getValue(), key);
                if (got != null && !got.isBlank()) return got;
            }
        } else if (node.isArray()) {
            for (JsonNode x : node) {
                String got = findByKey(x, key);
                if (got != null && !got.isBlank()) return got;
            }
        }

        return null;
    }
}