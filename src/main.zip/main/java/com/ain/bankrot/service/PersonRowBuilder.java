package com.ain.bankrot.service;

import com.ain.bankrot.api.ApiClient;
import com.ain.bankrot.api.FedresursEndpoints;
import com.ain.bankrot.model.physical.PhysicalPersonRow;
import com.ain.bankrot.util.RegionExtractor;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class PersonRowBuilder {

    private final ApiClient fed;
    private final ObjectMapper om = new ObjectMapper();
    private final PersonMapper personMapper = new PersonMapper();

    public PersonRowBuilder(ApiClient fed) {
        this.fed = fed;
    }

    /**
     * itemFromBankrotList — элемент из списка банкротов (bankrot.fedresurs.ru/backend/...),
     * где есть guid и lastLegalCase.
     */
    public PhysicalPersonRow buildFromListItem(JsonNode itemFromBankrotList) throws Exception {
        String guid = itemFromBankrotList.path("guid").asText("");
        PhysicalPersonRow row = new PhysicalPersonRow();
        if (guid.isBlank()) return row;

        // -----------------------------
        // 1) Деловые поля из списка (lastLegalCase)
        // -----------------------------
        JsonNode last = itemFromBankrotList.path("lastLegalCase");

        row.caseNumber = firstNonBlank(
                last.path("number").asText(""),
                last.path("caseNumber").asText("")
        );

        row.bankruptcyStatus = firstNonBlank(
                last.path("status").path("description").asText(""),
                last.path("status").path("name").asText(""),
                last.path("statusName").asText(""),
                last.path("status").asText("")
        );

        row.procedureType = firstNonBlank(
                last.path("procedure").path("name").asText(""),
                last.path("procedure").asText(""),
                last.path("procedureType").asText("")
        );

        row.arbitrationManagerName = firstNonBlank(
                last.path("arbitrManagerFio").asText(""),
                last.path("arbitrationManager").path("name").asText(""),
                last.path("arbitrManager").path("name").asText(""),
                last.path("manager").path("name").asText("")
        );

        // region если он есть в списке
        row.region = firstNonBlank(
                itemFromBankrotList.path("region").path("name").asText(""),
                itemFromBankrotList.path("region").asText("")
        );

        // -----------------------------
        // 2) Карточка физлица (fedresurs.ru/backend/persons/{guid})
        // ВОТ ТУТ ИМЕНА, ИНН, СНИЛС, АДРЕС
        // -----------------------------
        String personPath = FedresursEndpoints.person(guid);
        String personJson = fed.get(personPath, refererFed());
        PhysicalPersonRow base = personMapper.fromPersonJson(personJson, "https://fedresurs.ru" + personPath);

        mergePhysical(row, base);

        // если region пуст — парсим из адреса
        if (row.region.isBlank()) row.region = RegionExtractor.extract(row.residenceAddress);

        // -----------------------------
        // 3) PreviousFullName fallback: /general-info (если пусто)
        // -----------------------------
        if (row.previousFullName.isBlank()) {
            try {
                String gj = fed.get(FedresursEndpoints.personGeneralInfo(guid), refererFed());
                JsonNode gr = om.readTree(gj);

                // названия ключей могут плавать — ищем глубоко
                String prev = firstNonBlank(
                        findDeep(gr, "previousFullName", "previousName", "oldName"),
                        findDeep(gr, "fioPrevious", "fullNamePrevious")
                );

                if (!prev.isBlank() && !prev.equalsIgnoreCase(row.fullName)) {
                    row.previousFullName = prev;
                }
            } catch (Exception ignore) {}
        }

        return row;
    }

    // =========================================================
    // merge helpers
    // =========================================================

    private static void mergePhysical(PhysicalPersonRow target, PhysicalPersonRow base) {
        // Мержим персональные данные (а не деловые поля из списка)
        target.fullName = base.fullName;
        target.previousFullName = base.previousFullName;
        target.inn = base.inn;
        target.snils = base.snils;
        target.birthDate = base.birthDate;
        target.birthPlace = base.birthPlace;
        target.residenceAddress = base.residenceAddress;
        if (target.region.isBlank()) target.region = base.region;
        target.sourceUrl = base.sourceUrl;
    }

    private static Map<String, String> refererFed() {
        return Map.of("Referer", "https://fedresurs.ru/");
    }

    private static String firstNonBlank(String... xs) {
        for (String x : xs) if (x != null && !x.isBlank()) return x.trim();
        return "";
    }

    // =========================================================
    // deep-find (поиск ключей в любом месте JSON)
    // =========================================================
    private static String findDeep(JsonNode root, String... keys) {
        if (root == null || root.isNull() || root.isMissingNode()) return "";
        for (String k : keys) {
            String v = findByKey(root, k);
            if (v != null && !v.isBlank()) return v.trim();
        }
        return "";
    }

    private static String findByKey(JsonNode node, String key) {
        if (node == null || node.isNull() || node.isMissingNode()) return null;

        if (node.isObject()) {
            JsonNode direct = node.get(key);
            if (direct != null && !direct.isNull()) {
                String s = direct.asText("");
                if (s != null && !s.isBlank()) return s;

                String name = direct.path("name").asText("");
                if (!name.isBlank()) return name;
            }

            var it = node.fields();
            while (it.hasNext()) {
                var e = it.next();
                String got = findByKey(e.getValue(), key);
                if (got != null && !got.isBlank()) return got;
            }
        } else if (node.isArray()) {
            for (JsonNode x : node) {
                String got = findByKey(x, key);
                if (got != null && !got.isBlank()) return got;
            }
        }
        return null;
    }
}
