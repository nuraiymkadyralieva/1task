package com.ain.bankrot.service;

import com.ain.bankrot.model.physical.PhysicalPersonRow;
import com.ain.bankrot.util.Dates;
import com.ain.bankrot.util.RegionExtractor;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PersonMapper {

    private final ObjectMapper om = new ObjectMapper();

    public PhysicalPersonRow fromPersonJson(String personJson, String sourceUrl) throws Exception {
        JsonNode p = om.readTree(personJson);

        PhysicalPersonRow row = new PhysicalPersonRow();
        row.sourceUrl = sourceUrl;

        // --- ФИО (умный разбор) ---
        row.fullName = buildFullName(p);

        // --- идентификаторы ---
        row.inn = p.path("inn").asText("");
        row.snils = p.path("snils").asText("");

        // --- дата и место рождения ---
        row.birthDate = Dates.toDdMmYyyyFromIsoDateTime(
                firstNonBlank(
                        p.path("birthdateBankruptcy").asText(""),
                        p.path("birthDate").asText("")
                )
        );

        row.birthPlace = firstNonBlank(
                p.path("birthplaceBankruptcy").asText(""),
                p.path("birthPlace").asText("")
        );

        // --- адрес проживания ---
        row.residenceAddress = firstNonBlank(
                p.path("address").asText(""),
                p.path("residenceAddress").asText("")
        );

        // --- регион из адреса ---
        row.region = RegionExtractor.extract(row.residenceAddress);

        // --- прошлое ФИО ---
        row.previousFullName = extractPreviousName(p);

        return row;
    }

    // ================= helpers =================

    /** Собирает ФИО из всех возможных вариантов */
    private static String buildFullName(JsonNode p) {

        // 1) готовые строки
        String direct = firstNonBlank(
                p.path("fullName").asText(""),
                p.path("fio").asText(""),
                p.path("name").asText("")
        );
        if (!direct.isBlank()) return direct;

        // 2) раздельные поля
        String last = p.path("lastName").asText("");
        String first = p.path("firstName").asText("");
        String middle = p.path("middleName").asText("");

        String combined = (last + " " + first + " " + middle)
                .trim()
                .replaceAll("\\s+", " ");

        return combined;
    }

    /** Достаёт предыдущее ФИО из nameHistories */
    private static String extractPreviousName(JsonNode p) {
        JsonNode histories = p.path("nameHistories");
        if (!histories.isArray()) return "";

        for (JsonNode h : histories) {
            String prev = firstNonBlank(
                    h.path("fullName").asText(""),
                    h.path("fio").asText(""),
                    h.path("name").asText("")
            );
            if (!prev.isBlank()) return prev;
        }
        return "";
    }

    private static String firstNonBlank(String... xs) {
        for (String x : xs) {
            if (x != null && !x.isBlank()) return x.trim();
        }
        return "";
    }
}
